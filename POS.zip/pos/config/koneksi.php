<?php
return $conn = array(
	'host' => 'localhost', 
	'user' => 'root',
	'pass' => '',
	'dbnm' => 'db_pos'
);

?>